Thank you for downloading Animated Spider.

To use the spider simply drag the prefab into your scene, create your animator controller, and hook up the controller to the animator.

If you have any questions please contact support@prismbucket.com