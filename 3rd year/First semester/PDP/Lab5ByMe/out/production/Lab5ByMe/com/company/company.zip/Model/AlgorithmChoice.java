package com.company.Model;

public enum AlgorithmChoice {
    CLASSIC,
    KARATSUBA
}
