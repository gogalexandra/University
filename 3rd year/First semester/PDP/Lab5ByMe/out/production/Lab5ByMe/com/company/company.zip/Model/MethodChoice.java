package com.company.Model;

public enum MethodChoice {
    SEQUENTIAL,
    PARALLEL
}
