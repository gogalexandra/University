export interface DocumentMapped {
    id: number;
    title: string;
    author: string;
    noOfPages: number;
    type: string;
    format: string;
}