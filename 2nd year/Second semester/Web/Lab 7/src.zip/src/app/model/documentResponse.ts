import { DocumentMapped } from "./documentMapped";

export interface documentResponse {

    //info: [number, string, string, number, string, string][];
    info: Array<DocumentMapped>;
}