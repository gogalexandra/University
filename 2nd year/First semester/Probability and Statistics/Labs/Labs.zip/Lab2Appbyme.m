#Application
n = 3
p = 0.5
x = 0:n

#a
plot(x, binopdf(x, n, p), '*r') 
hold on

#b
stairs(binocdf(x, n , p))
hold on
printf("Cdf: \n")
binocdf(0, n, p)
binocdf(0, n, p) + binocdf(1, n, p)
binocdf(0, n, p) + binocdf(1, n, p) + binocdf(2, n, p)
binocdf(0, n, p) + binocdf(1, n, p) + binocdf(2, n, p) + binocdf(3, n, p)

#c
printf("\nP(X=0): %f \n" , binocdf(0, n, p))
printf("P(X!=1): %f \n" , binocdf(0, n, p) + binocdf(2, n, p) + binocdf(3, n, p))

#d
printf("P(X<=2): %f \n", binocdf(0, n, p) + binocdf(1, n, p) + binocdf(2, n, p))
printf("P(X<2): %f \n", binocdf(0, n, p) + binocdf(1, n, p))

#e
printf("P(X>=1): %f \n", binocdf(1, n, p) + binocdf(2, n, p) + binocdf(3, n, p))
printf("P(X>1): %f \n", binocdf(2, n, p) + binocdf(3, n, p))
