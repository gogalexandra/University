#a
n = 3
p = 0.5
x = 0:n
binopdf(x, n , p)

#b
n = 3
p = 0.5
x = 0:n
stairs(binocdf(x, n , p)
