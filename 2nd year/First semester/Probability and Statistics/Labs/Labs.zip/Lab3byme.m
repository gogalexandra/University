mu = input('Give mu: ')
sigma = input('Give sigma: ')
alpha = input('Give alpha: ')
beta = input('Give beta: ')

#Normal dis
#a
printf("\nP(X<=0): %f \n" , normcdf(0, mu, sigma))
printf("\nP(X>=0): %f \n" , 1 - normcdf(0, mu, sigma))

#b
printf("\nP(-1<=X<=1): %f \n" , normcdf(-1, mu, sigma) - normcdf(1, mu, sigma))
printf("\nP(-1<=X<=1): %f \n" ,1 - (normcdf(-1, mu, sigma) - normcdf(1, mu, sigma)))

#c
printf("\nX such that P(X<alpha): %f \n" , norminv(alpha, mu, sigma))

#d
printf("\nX such that P(X>beta): %f \n" , norminv(1 - beta, mu, sigma))

#Student dis
n = input('Give n: ')

#a
printf("\nP(X<=0): %f \n" , tcdf(0, n))
printf("\nP(X>=0): %f \n" , 1 - tcdf(0, n))

#b
printf("\nP(-1<=X<=1): %f \n" , tcdf(-1, n) - tcdf(1, n))
printf("\nP(-1<=X<=1): %f \n" ,1 - (tcdf(-1, n) - tcdf(1, n)))

#c
printf("\nX such that P(X<alpha): %f \n" , tinv(alpha,n))

#d
printf("\nX such that P(X>beta): %f \n" , tinv(1 - beta, n))