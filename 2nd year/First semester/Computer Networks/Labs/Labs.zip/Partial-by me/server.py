import socket
import select
import pickle
import sys


def send_to_all(clients, adr):
    msg = f"Client {adr} has connected"
    for x in clients:
        s.sendto(pickle.dumps(msg), x)

def send_all_adr(new_cs, clients_addresses):
    cs.send(pickle.dumps(len(clients_addresses)))
    for adr in clients_addresses:
        cs.send(pickle.dumps(adr))

# creating the server socket for connection
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('0.0.0.0', 5555))
s.setblocking(False)
s.listen(5)

# list of all addresses from connected clients
clients_addresses = []

ins = [s]
outs = []
msg = []



while ins:
    r, w, e = select.select(ins, outs, ins)
    for cs in r:
        if cs == s:
            # new socket (wanna add it to the clients list)
            new_cs, adr = s.accept()
            print(f"New connection from {adr}")
            # send message to all clients that a new one arrived
            send_to_all(ins, adr)
            ins.append(adr)
            # send to the new client all addresses of the one already existing
            send_all_adr(new_cs, clients_addresses)
            clients_addresses.append(adr)
        else:
