package Model.Utils;

import java.util.ArrayList;

public interface MyITriplet<T1, T2, T3> {
    T1 getValue0();
    T2 getValue1();
    T3 getValue2();
}
