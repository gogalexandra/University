package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;

//public class HelloApplication extends Application {
//    private Controller ctr1, ctr2, ctr3, ctr4, ctr5, ctr6, ctr7, ctr8, ctr9, ctr10;
//    private Controller currentController;
//    private int currSelectedPsIdIndex[] = {0};
//
//    private Text nrOfPrgStates = new Text();
//    private TableView heapTable = new TableView();
//    private ListView<Text> output = new ListView<>();
//    private ListView<Text> fileTable = new ListView<>();
//    private ListView<Text> programStatesIdent = new ListView<>();
//    private TableView symTable = new TableView();
//    private ListView<Text> exeStack = new ListView<>();
//
//    private Button oneStep =  new Button("Execute one step");
//    private Button load =  new Button("Load program");
//
//    private int getPsIdForSelectedViewIndex() {
//        return this.currentController.getRepo().getPrgList().get(this.currSelectedPsIdIndex[0]).getId();
//    }
//
//    private void updateHeapTable() {
//        this.heapTable.getItems().clear();
//        this.currentController.getRepo().getPrgList().forEach(
//                (ps) -> {
//                    if (ps.getId() == this.getPsIdForSelectedViewIndex()) {
//                        ObservableList<Map.Entry<Integer, Value>> heapTableViewItems = FXCollections.observableArrayList(ps.getHeap().getContent().entrySet());
//                        this.heapTable.getItems().addAll(heapTableViewItems);
//                    }
//                }
//        );
//    }
//
//    private void updateOutput() {
//        this.output.getItems().clear();
//        this.currentController.getRepo().getPrgList().forEach(
//                (ps) -> {
//                    if (ps.getId() == this.getPsIdForSelectedViewIndex()) {
//                        Text psOutputText = new Text(ps.getOutput().toString());
//                        psOutputText.wrappingWidthProperty().bind(output.widthProperty());
//                        this.output.getItems().add(psOutputText);
//                    }
//                }
//        );
//    }
//
//    private void updateFileTable() {
//        this.fileTable.getItems().clear();
//        /*this.currentController.getRepo().getPrgList().forEach(
//                (ps) -> {
//                    ObservableList<Map<Value, BufferedReader>> fileTableViewItems = FXCollections.observableArrayList(ps.getFileTable().getContent());
//                    this.fileTable.getItems().addAll(fileTableViewItems);
//                }
//        );*/
//    }
//
//    private void updateProgramStatesListView() {
//        this.programStatesIdent.getItems().clear();
//        this.currentController.getRepo().getPrgList().forEach(
//                (ps) -> {
//                    Text psIdText = new Text(String.valueOf(ps.getId()));
//                    psIdText.wrappingWidthProperty().bind(this.programStatesIdent.widthProperty());
//                    this.programStatesIdent.getItems().add(psIdText);
//                }
//        );
//
//        //this.programStatesListView.getSelectionModel().select(0);
//    }
//
//    public void updateSymTableView() {
//        this.symTable.getItems().clear();
//        this.currentController.getRepo().getPrgList().forEach(
//                (ps) -> {
//                    if (ps.getId() == this.getPsIdForSelectedViewIndex()) {
//                        ObservableList<Map<String, Value>> symTableViewItems = FXCollections.observableArrayList(ps.getSymTable().getContent());
//                        this.symTable.getItems().addAll(symTableViewItems);
//                    }
//                }
//        );
//    }
//
//    public void updateExeStack() {
//        this.exeStack.getItems().clear();
//        this.currentController.getRepo().getPrgList().forEach(
//                (ps) -> {
//                    if (ps.getId() == this.getPsIdForSelectedViewIndex()) {
//                        ObservableList<Text> exeStackListViewItems = FXCollections.observableArrayList();
//                        for (IStmt elem : ps.getStk().getStack()) {
//                            Text t = new Text(elem.toString());
//                            t.wrappingWidthProperty().bind(this.exeStack.widthProperty());
//                            exeStackListViewItems.add(t);
//                        }
//
//                        this.exeStack.getItems().addAll(exeStackListViewItems);
//                    }
//                }
//        );
//    }
//
//    @Override
//    public void start(Stage stage) throws IOException {
//        //FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
//
//        //Creating the coresponding lables
//        Label lb1 = new Label("Heap Table");
//        Label lb2 = new Label("Output");
//        Label lb3 = new Label("Symbol Table");
//        Label lb4 = new Label("File Table");
//        Label lb5 = new Label("Exe Stack");
//        Label lb6 = new Label("Nr of program states");
//        Label lb7 = new Label("List of PrgState identifiers");
//
//        //Setting HeapTable
//        heapTable.setEditable(true);
//        TableColumn c1 = new TableColumn("Address");
//        TableColumn c2 = new TableColumn("Value");
//        heapTable.getColumns().addAll(c1, c2);
//        this.heapTable.setPrefSize(100, 500);
//        this.heapTable.setMaxWidth(300);
//
//        //Setting SymbolTable
//        symTable.setEditable(true);
//        TableColumn c3 = new TableColumn("Variable name");
//        TableColumn c4 = new TableColumn("Value");
//        symTable.getColumns().addAll(c3, c4);
//        symTable.setMaxWidth(300);
//        this.symTable.setPrefSize(100, 500);
//
//        fileTable.setMaxWidth(300);
//        fileTable.setPrefSize(100, 500);
//        output.setMaxWidth(300);
//        output.setPrefSize(100, 500);
//        exeStack.setMaxWidth(300);
//        exeStack.setPrefSize(100, 500);
//        programStatesIdent.setMaxWidth(300);
//        programStatesIdent.setPrefSize(100, 150);
//
//        //Creating the box
//        VBox vbox = new VBox();
//        vbox.setSpacing(5);
//        vbox.setPadding(new Insets(10, 0, 0, 10));
//        vbox.getChildren().addAll(lb1, heapTable);
//        vbox.getChildren().addAll(lb3, symTable);
//        vbox.getChildren().addAll(lb2, output);
//        vbox.getChildren().addAll(lb4, fileTable);
//        vbox.getChildren().addAll(lb5, exeStack);
//        vbox.getChildren().addAll(lb6, nrOfPrgStates);
//        vbox.getChildren().addAll(lb7, programStatesIdent);
//
//        //Here are the options
//        IStmt ex1 = new CompStmt(new VarDeclStmt("v", new IntType()),
//                new CompStmt(new AssignStmt("v", new ValueExp(new IntValue(2))),
//                        new PrintStmt(new VarExp("v"))));
//
//        MyDictionary<String, Type> typeEnvir1 = new MyDictionary<>();
//        ex1.typecheck(typeEnvir1);
//        PrgState prg1 = new PrgState(ex1);
//        List<PrgState> l1 = new ArrayList<PrgState>(){{add(prg1); }};
//        IRepo repo1 = new Repo(l1, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log1");
//        ctr1 = new Controller(repo1);
//
//        IStmt ex2 = new CompStmt(new VarDeclStmt("a", new IntType()), new CompStmt(new VarDeclStmt("b", new IntType()),
//                new CompStmt(new AssignStmt("a", new ArithExp('+', new ValueExp(new IntValue(2)), new ArithExp('*',
//                        new ValueExp(new IntValue(3)), new ValueExp(new IntValue(5))))), new CompStmt(
//                        new AssignStmt("b", new ArithExp('+', new VarExp("a"), new ValueExp(new IntValue(1)))),
//                        new PrintStmt(new VarExp("b"))))));
//
//
//        MyDictionary<String, Type> typeEnvir2 = new MyDictionary<>();
//        ex2.typecheck(typeEnvir2);
//        PrgState prg2 = new PrgState(ex2);
//        List<PrgState> l2 = new ArrayList<PrgState>(){{add(prg2); }};
//        IRepo repo2 = new Repo(l2, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log2");
//        ctr2 = new Controller(repo2);
//
//
//        IStmt ex3 = new CompStmt(new VarDeclStmt("a", new BoolType()), new CompStmt(new VarDeclStmt("v",
//                new IntType()), new CompStmt(new AssignStmt("a", new ValueExp(new BoolValue(true))),
//                new CompStmt(new IfStmt(new VarExp("a"), new AssignStmt("v", new ValueExp(new IntValue(2))),
//                        new AssignStmt("v", new ValueExp(new IntValue(3)))), new PrintStmt(new
//                        VarExp("v"))))));
//
//
//        MyDictionary<String, Type> typeEnvir3 = new MyDictionary<>();
//        ex3.typecheck(typeEnvir3);
//        PrgState prg3 = new PrgState(ex3);
//        List<PrgState> l3 = new ArrayList<PrgState>(){{add(prg3); }};
//        IRepo repo3 = new Repo(l3, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log3");
//        ctr3 = new Controller(repo3);
//
//        IStmt ex4 = new CompStmt(new VarDeclStmt("varf", new StringType()),
//                new CompStmt(new AssignStmt("varf", new ValueExp(new StringValue("test.in"))),
//                        new CompStmt(new openRFile(new VarExp("varf")),
//                                new CompStmt(new VarDeclStmt("varc", new IntType()),
//                                        new CompStmt(new readFile(new VarExp("varf"), "varc"),
//                                                new CompStmt(new PrintStmt(new VarExp("varc")),
//                                                        new CompStmt(new readFile(new VarExp("varf"), "varc"),
//                                                                new CompStmt(new PrintStmt(new VarExp("varc")), new closeRFile(new VarExp("varf"))))))))));
//
//
//        MyDictionary<String, Type> typeEnvir4 = new MyDictionary<>();
//        ex4.typecheck(typeEnvir4);
//        PrgState prg4 = new PrgState(ex4);
//        List<PrgState> l4 = new ArrayList<PrgState>(){{add(prg4); }};
//        IRepo repo4 = new Repo(l4, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log4");
//        ctr4 = new Controller(repo4);
//
//        IStmt ex5 = new CompStmt(new VarDeclStmt("v", new RefType(new IntType())),
//                new CompStmt(new newAlloc("v", new ValueExp(new IntValue(20))),
//                        new CompStmt(new VarDeclStmt("a", new RefType(new RefType(new IntType()))),
//                                new CompStmt(new newAlloc("a", new VarExp("v")),
//                                        new CompStmt(new PrintStmt(new VarExp("v")), new PrintStmt(new VarExp("a")))))));
//
//        MyDictionary<String, Type> typeEnvir5 = new MyDictionary<>();
//        ex5.typecheck(typeEnvir5);
//        PrgState prg5 = new PrgState(ex5);
//        List<PrgState> l5 = new ArrayList<PrgState>(){{add(prg5); }};
//        IRepo repo5 = new Repo(l5, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log5");
//        ctr5 = new Controller(repo5);
//
//
//        IStmt ex6 = new CompStmt(new VarDeclStmt("v", new RefType(new IntType())),
//                new CompStmt(new newAlloc("v", new ValueExp(new IntValue(20))),
//                        new CompStmt(new VarDeclStmt("a", new RefType(new RefType(new IntType()))),
//                                new CompStmt(new newAlloc("a", new VarExp("v")),
//                                        new CompStmt(new PrintStmt(new rH(new VarExp("v"))),
//                                                new PrintStmt(new ArithExp('+', new ValueExp(new IntValue(5)),
//                                                        new rH(new rH(new VarExp("a"))))))))));
//
//        MyDictionary<String, Type> typeEnvir6 = new MyDictionary<>();
//        ex6.typecheck(typeEnvir6);
//        PrgState prg6 = new PrgState(ex6);
//        List<PrgState> l6 = new ArrayList<PrgState>(){{add(prg6); }};
//        IRepo repo6 = new Repo(l6, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log6");
//        ctr6 = new Controller(repo6);
//
//        IStmt ex7 = new CompStmt(new VarDeclStmt("v", new RefType(new IntType())),
//                new CompStmt(new newAlloc("v", new ValueExp(new IntValue(20))),
//                        new CompStmt(new PrintStmt(new rH(new VarExp("v"))), new CompStmt(
//                                new wH("v", new ValueExp(new IntValue(30))),
//                                new PrintStmt(new ArithExp('+', new ValueExp(new IntValue(5)),
//                                        new rH(new VarExp("v"))))))));
//
//        MyDictionary<String, Type> typeEnvir7 = new MyDictionary<>();
//        ex7.typecheck(typeEnvir7);
//        PrgState prg7 = new PrgState(ex7);
//        List<PrgState> l7 = new ArrayList<PrgState>(){{add(prg7); }};
//        IRepo repo7 = new Repo(l7, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log7");
//        ctr7 = new Controller(repo7);
//
//        IStmt ex8 = new CompStmt(new VarDeclStmt("v", new RefType(new IntType())),
//                new CompStmt(new newAlloc("v", new ValueExp(new IntValue(20))),
//                        new CompStmt(new VarDeclStmt("a", new RefType(new RefType(new IntType()))),
//                                new CompStmt(new newAlloc("a", new VarExp("v")),
//                                        new CompStmt(new newAlloc("v", new ValueExp(new IntValue(30))),
//                                                new PrintStmt(new rH(new rH(new VarExp("a")))))))));
//
//        MyDictionary<String, Type> typeEnvir8 = new MyDictionary<>();
//        ex8.typecheck(typeEnvir8);
//        PrgState prg8 = new PrgState(ex8);
//        List<PrgState> l8 = new ArrayList<PrgState>(){{add(prg8); }};
//        IRepo repo8 = new Repo(l8, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log8");
//        ctr8 = new Controller(repo8);
//
//        IStmt ex9 = new CompStmt(new VarDeclStmt("v", new IntType()),
//                new CompStmt(new AssignStmt("v", new ValueExp(new IntValue(4))),
//                        new CompStmt(new WhileStmt(new RelationalExp(new VarExp("v"), new ValueExp(new IntValue(0)), ">"),
//                                new CompStmt(new PrintStmt(new VarExp("v")),
//                                        new AssignStmt("v",
//                                                new ArithExp('-', new VarExp("v"), new ValueExp(new IntValue(1)))))),
//                                new PrintStmt(new VarExp("v")))));
//
//        MyDictionary<String, Type> typeEnvir9 = new MyDictionary<>();
//        ex9.typecheck(typeEnvir9);
//        PrgState prg9 = new PrgState(ex9);
//        List<PrgState> l9 = new ArrayList<PrgState>(){{add(prg9); }};
//        IRepo repo9 = new Repo(l9, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log9");
//        ctr9 = new Controller(repo9);
//
//        IStmt ex10 = new CompStmt(new VarDeclStmt("v", new IntType()),
//                new CompStmt( new VarDeclStmt("a", new RefType(new IntType())),
//                        new CompStmt(new AssignStmt("v", new ValueExp(new IntValue(10))),
//                                new CompStmt(new newAlloc("a", new ValueExp(new IntValue(22))),
//                                        new CompStmt(new ForkStmt(
//                                                new CompStmt(new wH("a", new ValueExp(new IntValue(30))),
//                                                        new CompStmt(new AssignStmt("v", new ValueExp(new IntValue(32))),
//                                                                new CompStmt(new PrintStmt(new VarExp("v")),
//                                                                        new PrintStmt(new rH(new VarExp("a"))))))),
//                                                new CompStmt(new PrintStmt(new VarExp("v")),
//                                                        new PrintStmt(new rH(new VarExp("a")))))))));
//
//        MyDictionary<String, Type> typeEnvir10 = new MyDictionary<>();
//        ex10.typecheck(typeEnvir10);
//        PrgState prg10 = new PrgState(ex10);
//        List<PrgState> l10 = new ArrayList<PrgState>();
//        l10.add(prg10);
//        IRepo repo10 = new Repo(l10, "C:\\UBB Sem 3\\Map\\Labs\\Interpretor 1.4\\log10");
//        ctr10 = new Controller(repo10);
//
//        ListView<Text> optionList = new ListView<>();
//
//        // ADD TEXT TO LISTVIEW
//        Text t1 = new Text(ex1.toString());
//        t1.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t2 = new Text(ex2.toString());
//        t2.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t3 = new Text(ex3.toString());
//        t3.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t4 = new Text(ex4.toString());
//        t4.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t5 = new Text(ex5.toString());
//        t5.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t6 = new Text(ex6.toString());
//        t6.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t7 = new Text(ex7.toString());
//        t7.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t8 = new Text(ex8.toString());
//        t8.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t9 = new Text(ex9.toString());
//        t9.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        Text t10 = new Text(ex10.toString());
//        t10.wrappingWidthProperty().bind(optionList.widthProperty());
//
//        optionList.getItems().addAll(t1, t2, t3, t4, t5, t6, t7, t8, t9, t10);
//        optionList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
//
//        StackPane secondLayout = new StackPane();
//        Scene secondScene = new Scene(secondLayout, 800, 300);
//        Stage secondWindow = new Stage();
//        HBox hbox2 = new HBox();
//        hbox2.getChildren().add(optionList);
//        //secondLayout.getChildren().add(optionList);
//
//        HBox hbox = new HBox();
//        hbox.getChildren().addAll(oneStep, load);
//        secondLayout.getChildren().addAll(hbox, hbox2);
//        hbox.setAlignment(Pos.TOP_LEFT);
//        hbox2.setAlignment(Pos.TOP_RIGHT);
//
//
//        secondWindow.setTitle("Runnable programs");
//        secondWindow.setScene(secondScene);
//        secondWindow.show();
//
//
//
////        Label lb7 = new Label("Runnable programs");
////        HBox hbox2 = new HBox();
////        hbox2.getChildren().addAll(lb7, optionList);
////        hbox2.setAlignment(Pos.TOP_RIGHT);
////        vbox.getChildren().add(hbox2);
//        //vbox.getChildren().add(secondLayout);
//        //VBox.setAlignment(Pos.TOP_RIGHT);
//        //Creating the scene
//        Scene scene = new Scene(vbox, 500, 600);
//        stage.setTitle("Program");
//        stage.setScene(scene);
//        stage.show();
//
////        this.load.setOnAction(event -> {
////            try {
////                // TODO figure out why I need this 2 times
////                //if (!this.currentController.getRepo().getProgramStates().forEach();)
////                this.currentController.executeOneStepTEST();
////                //if (!this.currentController.getRepo().getProgramStates().isEmpty())
////                this.currentController.executeOneStepTEST();
////
////                this.updateHeapTableView();
////                this.updateOutListView();
////                this.updateFileTableView();
////                this.updateProgramStatesListView();
////                this.updateSymTableView();
////                this.updateExeStackListView();
////            } catch (InterruptedException e) {
////                e.printStackTrace();
////            }
////        });
//
//        //OPTION SELECTED
//        optionList.setOnMouseClicked((event) -> {
//            int selectedIndex = optionList.getSelectionModel().getSelectedIndex();
//            if (selectedIndex != -1)
//                this.currSelectedPsIdIndex[0] = selectedIndex;
//
//            this.nrOfPrgStates.setText("Number of program states = " + String.valueOf(getSelectedCtr().getRepo().getPrgList().size()));
//            this.currentController = getSelectedCtr();
//
//            this.updateHeapTable();
//            this.updateOutput();
//            this.updateFileTable();
//            this.updateSymTableView();
//            this.updateExeStack();
//            this.updateProgramStatesListView();
//        });
//    }
//
//    private Controller getSelectedCtr() {
//        switch (this.currSelectedPsIdIndex[0]){
//            case 0:
//                return ctr1;
//
//            case 1:
//                return ctr2;
//
//            case 2:
//                return ctr3;
//
//            case 3:
//                return ctr4;
//
//            case 4:
//                return ctr5;
//
//            case 5:
//                return ctr6;
//
//            case 6:
//                return ctr7;
//
//            case 7:
//                return ctr8;
//
//            case 8:
//                return ctr9;
//
//            case 9:
//                return ctr10;
//
//            default:
//                return ctr1;
//        }
//    }
//
//    public static void main(String[] args) {
//        launch();
//    }
//}


public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        FXMLLoader mainLoader = new FXMLLoader();
        mainLoader.setLocation(getClass().getClassLoader().getResource("runForm2.fxml"));
        Parent mainWindow = mainLoader.load();

        PrgRunController mainWindowController = mainLoader.getController();

        primaryStage.setTitle("Main Window");
        primaryStage.setScene(new Scene(mainWindow, 620, 600));
        primaryStage.show();


        FXMLLoader secondaryLoader = new FXMLLoader();
        secondaryLoader.setLocation(getClass().getClassLoader().getResource("selectForm2.fxml"));
        Parent secondaryWindow = secondaryLoader.load();

        PrgListController selectWindowController = secondaryLoader.getController();
        selectWindowController.setMainWindowController(mainWindowController);

        Stage secondaryStage = new Stage();
        secondaryStage.setTitle("Select Window");
        secondaryStage.setScene(new Scene(secondaryWindow, 500, 550));
        secondaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}