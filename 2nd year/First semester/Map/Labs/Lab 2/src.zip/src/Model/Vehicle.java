package Model;

public interface Vehicle {
    public boolean checkRepairCost(int price);
    public int getRepairCost();
    public String toString();
}

